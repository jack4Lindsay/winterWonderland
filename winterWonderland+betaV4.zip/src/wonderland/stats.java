package wonderland;
import javax.swing.*;
import java.awt.*;
class stats{
	Thread t;
	int tt = 4;
	boolean alive = true, active = false;
	JLabel p = new JLabel();
	int numPengInteractions = 0, stepsTaken = 0, numCollisions = 0;
	JLabel numInteractions = new JLabel();
	Font pf = new Font("Consolas",1,16);
}