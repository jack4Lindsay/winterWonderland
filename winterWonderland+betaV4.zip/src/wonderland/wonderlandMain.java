package wonderland;
import javax.swing.*;
import java.awt.*;
import java.util.*;
class wonderlandMain{
	static JFrame jf = new JFrame("Winter Wonderland!");
	static JLayeredPane jl = new JLayeredPane();
	static int l = 1024, h = 768, mapMax = 8192;
	static String dir = "images+and+data\\";
	static player p1;
	static ThreadGroup rotg = new ThreadGroup("relative objects");
	static ThreadGroup sftg = new ThreadGroup("snowflakes");
	static ThreadGroup ptg = new ThreadGroup("phrases");
	static phraseBook pb = new phraseBook();
	static phrase specialPhrase;
	static achievements ach;
	static timeTracker ttr;
	static autosaver as;
	static Random ra = new Random();
	wonderlandMain(){
		jf.setSize(l,h);
		jf.setLocation((1920-l)/2,(1080-h)/2);
		jf.setDefaultCloseOperation(3);
		jf.setContentPane(jl);
		Color lightlightgray = new Color(224,224,224);
		jf.setBackground(lightlightgray);
		
		specialPhrase = new phrase("Something magical happened!");
		specialPhrase.bkgdc = new Color(255,240,224);
		
		for(int i = 0;i<24;i++){
			snowflake nsf = new snowflake();
			jf.add(nsf);
		}
		
		for(int i = 0;i<192;i++){
			createRandomObject();
		}
		
		p1 = new player();
		jf.add(p1);
		ach = new achievements();
		ach.loadData();
		ttr = new timeTracker();
		as = new autosaver();
		
		jf.setVisible(true);
	}
	void createRandomObject(){
		int a = ra.nextInt(10000);
		if(a % 3331 == 0){
			rudolph nru = new rudolph();
			jf.add(nru);
		}else if(a % 13 == 0){
			reindeer nr = new reindeer();
			jf.add(nr);
		}else if(a % 11 == 0){
			fairy nf = new fairy();
			jf.add(nf);
		}else if(a % 7 == 0){
			bear nb = new bear();
			jf.add(nb);
		}else if(a % 5 == 0){
			goblin ng = new goblin();
			jf.add(ng);
		}else if(a % 3 == 0){
			penguin np = new penguin();
			jf.add(np);
		}else if(a % 2 == 0){
			snowman nsm = new snowman();
			jf.add(nsm);
		}else{
			tree nt = new tree();
			jf.add(nt);
		}
	}
	public static void main(String[] arguments){
		wonderlandMain wm = new wonderlandMain();
	}
}