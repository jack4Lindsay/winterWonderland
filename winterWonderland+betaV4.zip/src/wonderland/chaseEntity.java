package wonderland;
import java.awt.*;
import java.awt.image.*;
class chaseEntity extends relativeObject{
	BufferedImage im;
	int skinID = 0;
	int counter = 0, anim = 0;
	int stillOrMove = 0, leftOrRight = 0;
	int xspd = 0, yspd = 0;
	chaseEntity(){
		super();
	}
	chaseEntity(int inpx, int inpy){
		super(inpx, inpy);
	}
	public void paintComponent(Graphics com){
		Graphics2D g = (Graphics2D) com;
		if(interacted == false){
			animate();
		}
		g.drawImage(im,0,0,l,h,(skinID*32)+(anim*16)+(leftOrRight*16),(stillOrMove*16),(skinID*32)+(anim*16)+16-(leftOrRight*16),(stillOrMove*16)+16,null);
		highlightCheck(g);
	}
	void animate(){
		if(wonderlandMain.p1.x-(x-wonderlandMain.p1.relx) < 256 && (x-wonderlandMain.p1.relx)-wonderlandMain.p1.x < 256 && wonderlandMain.p1.y-(y-wonderlandMain.p1.rely) < 256 && (y-wonderlandMain.p1.rely)-wonderlandMain.p1.y < 256){
			stillOrMove = 1;
			if(wonderlandMain.p1.x > x-wonderlandMain.p1.relx){
				xspd = 1;
				leftOrRight = 1;
			}else if(x-wonderlandMain.p1.relx > wonderlandMain.p1.x){
				xspd = -1;
				leftOrRight = 0;
			}else{xspd = 0;}
			if(wonderlandMain.p1.y > y-wonderlandMain.p1.rely){
				yspd = 1;
			}else if(y-wonderlandMain.p1.rely > wonderlandMain.p1.y){
				yspd = -1;
			}else{yspd = 0;}
			if(counter % 8 == 0){
				x+=xspd;
				y+=yspd;
			}
			if(counter >= 128){
				counter = 0;
				if(anim == 1){anim = 0;}else{anim++;}
			}
			counter++;
		}else{
			stillOrMove = 0;
			if(counter >= 256){
				counter = 0;
				if(anim == 1){anim = 0;}else{anim++;}
			}
			counter++;
		}
	}
}