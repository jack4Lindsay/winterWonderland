package wonderland;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.*;
class relativeObject extends JComponent implements Runnable, MouseListener, MouseMotionListener{
	Thread t;
	int tt = 2;
	boolean alive = true, frontOrBack = false, hit = false, highlighted = false, interacted = false;
	int x = 0, y = 0, l = 128, h = 128;
	Rectangle2D.Float outline = new Rectangle2D.Float();
	Random ra = new Random();
	phrase ph;
	relativeObject(int inpx, int inpy){
		x = inpx;
		y = inpy;
		boundSetting();
		addMouseListener(this);
		addMouseMotionListener(this);
		ph = new phrase();
		start();
	}
	relativeObject(){
		int rax = ra.nextInt(wonderlandMain.mapMax);
		if(rax % 2 == 1){rax--;}
		int ray = ra.nextInt(wonderlandMain.mapMax);
		if(ray % 2 == 1){ray--;}
		x = rax;
		y = ray;
		boundSetting();
		addMouseListener(this);
		addMouseMotionListener(this);
		ph = new phrase();
		start();
	}
	void boundSetting(){
		setBounds(x-wonderlandMain.p1.relx,y-wonderlandMain.p1.rely,l,h);
	}
	void highlightCheck(Graphics2D graf){
		if(highlighted == true){
			graf.setColor(Color.DARK_GRAY);
			outline.setFrame(0,0,l-1,h-1);
			graf.draw(outline);
		}
	}
	public void paintComponent(Graphics com){
		Graphics2D g = (Graphics2D) com;
		highlightCheck(g);
	}
	void start(){if(t == null){t = new Thread(wonderlandMain.rotg,this);t.start();}}
	public void run(){
		while(alive == true){
			if(x-wonderlandMain.p1.relx <= wonderlandMain.l && x-wonderlandMain.p1.relx >= -l && y-wonderlandMain.p1.rely <= wonderlandMain.h && y-wonderlandMain.p1.rely >= -h){
				boundSetting();
				checkForPlayerTouch();
				checkLayering();
				repaint();
			}
			if(interacted == true){
				animate();
				if(farEnough() == true){
					replaceWithRandomObject();
				}
			}
			try{t.sleep(tt);}catch(Exception e){}
		}
		wonderlandMain.jf.remove(this);
	}
	void animate(){}
	public void mouseMoved(MouseEvent me){}
	public void mouseDragged(MouseEvent me){ph.activate();interacted = true;}
	public void mouseClicked(MouseEvent me){ph.activate();interacted = true;}
	public void mouseEntered(MouseEvent me){highlighted = true;}
	public void mouseExited(MouseEvent me){highlighted = false;}
	public void mouseReleased(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	void checkForPlayerTouch(){
		try{
			player p = wonderlandMain.p1;
			int leftSidePlayer = p.x+((128*5)/16);
			int rightSidePlayer = p.x+((128*11)/16);
		
			if(p.touchingUp == false && p.touchingLeft == false && p.touchingDown == false && p.touchingRight == false && hit == true){hit = false;}
		
			if(((p.y+p.size == y+h-p.rely) && p.moveUp == true) && (leftSidePlayer < (x+l-p.relx) && rightSidePlayer > (x-p.relx)) && wonderlandMain.p1.touchingUp == false && hit == false){
				wonderlandMain.p1.touchingUp = true;
				wonderlandMain.p1.numCollisions++;
				hit = true;
			}else if((leftSidePlayer > (x+l-p.relx) || rightSidePlayer < (x-p.relx)) && wonderlandMain.p1.touchingUp == true && hit == true){
				wonderlandMain.p1.touchingUp = false;
				hit = false;
			}
		
		
			if(((p.y+p.size == y+((h*7)/8)-p.rely) && p.moveDown == true) && (leftSidePlayer < (x+l-p.relx) && rightSidePlayer > (x-p.relx)) && wonderlandMain.p1.touchingDown == false && hit == false){
				wonderlandMain.p1.touchingDown = true;
				wonderlandMain.p1.numCollisions++;
				hit = true;
			}else if((leftSidePlayer > (x+l-p.relx) || rightSidePlayer < (x-p.relx)) && wonderlandMain.p1.touchingDown == true && hit == true){
				wonderlandMain.p1.touchingDown = false;
				hit = false;
			}
		}catch(Exception e){}
	}
	void checkLayering(){
		try{
			player p = wonderlandMain.p1;
			if((p.y+p.size < y+h-p.rely) && frontOrBack == false){
				wonderlandMain.jl.moveToFront(this);
				frontOrBack = true;
			}else if((p.y+p.size >= y+h-p.rely) && frontOrBack == true){
				wonderlandMain.jl.moveToBack(this);
				frontOrBack = false;
			}
		}catch(Exception e){}
	}
	void replaceWithRandomObject(){
		int a = ra.nextInt(10000);
		if(a % 3331 == 0){
			rudolph nru = new rudolph(x,y);
			wonderlandMain.jf.add(nru);
		}else if(a % 13 == 0){
			reindeer nr = new reindeer(x,y);
			wonderlandMain.jf.add(nr);
		}else if(a % 11 == 0){
			fairy nf = new fairy(x,y);
			wonderlandMain.jf.add(nf);
		}else if(a % 7 == 0){
			bear nb = new bear(x,y);
			wonderlandMain.jf.add(nb);
		}else if(a % 5 == 0){
			goblin ng = new goblin(x,y);
			wonderlandMain.jf.add(ng);
		}else if(a % 3 == 0){
			penguin np = new penguin(x,y);
			wonderlandMain.jf.add(np);
		}else if(a % 2 == 0){
			snowman nsm = new snowman(x,y);
			wonderlandMain.jf.add(nsm);
		}else{
			tree nt = new tree(x,y);
			wonderlandMain.jf.add(nt);
		}
		ph.alive = false;
		alive = false;
	}
	boolean farEnough(){
		if((x-wonderlandMain.p1.relx < -(l*4)) || (x-wonderlandMain.p1.relx > wonderlandMain.l+l) || (y-wonderlandMain.p1.rely < -(h*4)) || (y-wonderlandMain.p1.rely > wonderlandMain.h+h)){return(true);}else{return(false);}
	}
}