package wonderland;
import java.io.*;
import javax.imageio.*;
import java.awt.event.*;
class fairy extends fleeEntity{
	File f = new File(wonderlandMain.dir + "wonderland+fairy.png");
	fairy(){
		super();
		try{im = ImageIO.read(f);}catch(Exception e){}
		skinID = ra.nextInt(4);
		l = 64;
		h = 64;
	}
	fairy(int inpx, int inpy){
		super(inpx, inpy);
		try{im = ImageIO.read(f);}catch(Exception e){}
		skinID = ra.nextInt(4);
		l = 64;
		h = 64;
	}
	public void mouseClicked(MouseEvent me){ph.activate("fa");interacted = true;}
	public void mouseDragged(MouseEvent me){ph.activate("fa");interacted = true;}
}