package wonderland;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
class phrase extends JComponent implements Runnable{
	Thread t;
	int tt = 4;
	boolean alive = true, active = false;
	JLabel p = new JLabel();
	Font pf = new Font("Consolas",1,16);
	int y = 96, h = 32;
	Rectangle2D.Float bkgd = new Rectangle2D.Float();
	Color bkgdc = Color.WHITE;
	phrase(){
		setBounds(0,wonderlandMain.h-80+y,wonderlandMain.l,h);
		p.setSize(wonderlandMain.l,h);
		p.setText(wonderlandMain.pb.getRandomPhrase());
		p.setFont(pf);
		p.setHorizontalAlignment(JLabel.CENTER);
		p.setVerticalAlignment(JLabel.CENTER);
		add(p);
		start();
		wonderlandMain.jf.add(this);
	}
	phrase(String t){
		setBounds(0,wonderlandMain.h-80+y,wonderlandMain.l,h);
		p.setSize(wonderlandMain.l,h);
		p.setText(t);
		p.setFont(pf);
		p.setHorizontalAlignment(JLabel.CENTER);
		p.setVerticalAlignment(JLabel.CENTER);
		add(p);
		start();
		wonderlandMain.jf.add(this);
	}
	public void paintComponent(Graphics com){
		Graphics2D g = (Graphics2D) com;
		g.setColor(bkgdc);
		bkgd.setFrame(0,0,wonderlandMain.l,h);
		g.fill(bkgd);
	}
	void activate(){
		if(active == false){
			active = true;
			wonderlandMain.p1.numInteractions++;
		}
	}
	void activate(String check){
		if(active == false){
			active = true;
			if(check == "pe"){
				wonderlandMain.p1.numInteractions++;wonderlandMain.p1.numPengInteractions++;
			}else if(check == "po"){
				wonderlandMain.p1.numInteractions++;wonderlandMain.p1.numBearInteractions++;
			}else if(check == "go"){
				wonderlandMain.p1.numInteractions++;wonderlandMain.p1.numGobInteractions++;
			}else if(check == "fa"){
				wonderlandMain.p1.numInteractions++;wonderlandMain.p1.numFairyInteractions++;
			}else if(check == "re"){
				wonderlandMain.p1.numInteractions++;wonderlandMain.p1.numReinInteractions++;
			}else if(check == "ru"){
				wonderlandMain.p1.numInteractions++;wonderlandMain.p1.numRudInteractions++;
			}
		}
	}
	void changePhrase(){
		p.setText(wonderlandMain.pb.getRandomPhrase());
	}
	void changePhrase(String inpt){
		p.setText(inpt);
	}
	void start(){if(t == null){t = new Thread(wonderlandMain.ptg,this);t.start();}}
	public void run(){
		while(alive == true){
			if(active == true){
				wonderlandMain.jl.moveToFront(this);
				for(int i = 0;i<112;i++){
					y--;
					setBounds(0,wonderlandMain.h-80+y,wonderlandMain.l,h);
					repaint();
					try{t.sleep(tt);}catch(Exception e){}
				}
				if(p.getText() == "GAH!!!! A GHOST!!!!"){wonderlandMain.ach.ghostPhrase = true;}
				try{t.sleep(4000);}catch(Exception e){}
				for(int i = 0;i<112;i++){
					y++;
					setBounds(0,wonderlandMain.h-80+y,wonderlandMain.l,h);
					repaint();
					try{t.sleep(tt);}catch(Exception e){}
				}
				active = false;
			}
			try{t.sleep(tt*8);}catch(Exception e){}
		}
		wonderlandMain.jf.remove(this);
	}
}