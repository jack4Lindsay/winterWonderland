package wonderland;
import java.awt.*;
import java.awt.image.*;
class neutralEntity extends relativeObject{
	BufferedImage im;
	int skinID = 0;
	int counter = 0, counter2 = 0, anim = 0, numAnim = 16;
	int stillOrMove = 0, leftOrRight = 0;
	int xspd = 0, yspd = 0;
	neutralEntity(){
		super();
	}
	neutralEntity(int inpx, int inpy){
		super(inpx, inpy);
	}
	public void paintComponent(Graphics com){
		Graphics2D g = (Graphics2D) com;
		if(interacted == false){
			animate();
		}
		g.drawImage(im,0,0,l,h,(skinID*32)+(anim*16)+(leftOrRight*16),(stillOrMove*16),(skinID*32)+(anim*16)+16-(leftOrRight*16),(stillOrMove*16)+16,null);
		highlightCheck(g);
	}
	void animate(){
		if(counter % 16 == 0 && stillOrMove == 1){
			x+=xspd;
			y+=yspd;
		}
		if(counter == 128 && stillOrMove == 1){
			counter = 0;
			counter2++;
			if(anim == 1){anim = 0;}else{anim++;}
		}else if(counter >= 256){
			counter = 0;
			counter2++;
			if(anim == 1){anim = 0;}else{anim++;}
		}
		if(counter2 == numAnim && stillOrMove == 0){
			counter2 = 0;
			stillOrMove = 1;
			int rax1 = ra.nextInt(2);
			int ray1 = ra.nextInt(2);
			int rax2 = ra.nextInt(2);
			int ray2 = ra.nextInt(2);
			if(rax2 == 1){xspd = rax1*-1;}else{xspd = rax1;}
			if(ray2 == 1){yspd = ray1*-1;}else{yspd = ray1;}
			if(xspd == 0 && yspd == 0){xspd = -1;yspd = -1;}
			if(xspd > 0){leftOrRight = 1;}else{leftOrRight = 0;}
			
		}else if(counter2 == (numAnim*2) && stillOrMove == 1){
			counter2 = 0;
			stillOrMove = 0;
			xspd = 0;
			yspd = 0;
		}
		counter++;
	}
}