package wonderland;
import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import javax.imageio.*;
import java.io.*;
class player extends JComponent implements Runnable{
	static Thread t;
	static int tt = 4;
	static boolean alive = true;
	static int size = 128;
	static int x = (wonderlandMain.l/2) - (size/2), y = (wonderlandMain.h/2) - (size/2), relx = 0, rely = 0, spd = 1;
	File f = new File(wonderlandMain.dir + "wonderland+elf.png");
	BufferedImage elfs;
	static keys k;
	boolean moveUp = false, moveLeft = false, moveDown = false, moveRight = false, touchingUp = false, touchingLeft = false, touchingDown = false, touchingRight = false;
	int anim = 0, leftOrRight = 0, moving = 0;
	int skinID = 0, numSkins = 15;
	int[] skinsUnlocked = {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	int numInteractions = 0, numPengInteractions = 0, numBearInteractions = 0, numGobInteractions = 0, numFairyInteractions = 0, 
		numReinInteractions = 0, numRudInteractions = 0, stepsTaken = 0, numCollisions = 0, minutesPlayed = 0;
	JLabel coord = new JLabel("[" + relx + "|" + rely + "]");
	Font fo = new Font("Consolas",0,16);
	player(){
		setSize(wonderlandMain.l,wonderlandMain.h);
		try{elfs = ImageIO.read(f);}catch(Exception e){}
		
		coord.setSize(wonderlandMain.l,wonderlandMain.h);
		coord.setVerticalAlignment(JLabel.TOP);
		add(coord);
		
		k = new keys();
		addKeyListener(k);
		setFocusable(true);
		
		start();
	}
	public void paintComponent(Graphics com){
		Graphics2D g = (Graphics2D) com;
		g.drawImage(elfs,x,y,x+size,y+size,(skinID*32)+(anim*16)+(leftOrRight*16),(moving*16),16+(skinID*32)+(anim*16)-(leftOrRight*16),16+(moving*16),null);
	}
	void start(){if(t == null){t = new Thread(this);t.start();}}
	public void run(){
		int counter = 0;
		while(alive == true){
			if(moveUp == true || moveLeft == true || moveDown == true || moveRight == true){moving = 1;}else{moving = 0;}
			if(counter == 128){
				counter = 0;
				if(anim == 1){anim = 0;}else{anim = 1;}
			}else if(counter == 64 && moving == 1){
				counter = 0;
				if(anim == 1){anim = 0;}else{anim = 1;}
				stepsTaken++;
			}else{counter++;}
			if(moveUp == true && touchingUp == false && rely > 0){
				rely-=spd;
				if(touchingDown == true){touchingDown = false;}
			}
			if(moveLeft == true && touchingLeft == false && relx > 0){
				relx-=spd;
				if(touchingRight == true){touchingRight = false;}
			}
			if(moveDown == true && touchingDown == false && rely < wonderlandMain.mapMax){
				rely+=spd;
				if(touchingUp == true){touchingUp = false;}
			}
			if(moveRight == true && touchingRight == false && relx < wonderlandMain.mapMax){
				relx+=spd;
				if(touchingLeft == true){touchingLeft = false;}
			}
			coord.setText("[" + relx + "|" + rely + "]");
			repaint();
			try{t.sleep(tt);}catch(Exception e){}
		}
	}
}