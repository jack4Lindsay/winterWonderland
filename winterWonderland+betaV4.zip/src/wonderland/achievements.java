package wonderland;
import java.io.*;
import java.awt.*;
class achievements implements Runnable{
	Thread t;
	int tt = 500;
	boolean alive = true;
	File data = new File(wonderlandMain.dir + "player+data.txt");
	phrase savePhrase = new phrase("Data saved successfully.");
	phrase unlockPhrase = new phrase("New skin unlocked!");
	boolean sawSanta = false, ghostPhrase = false;
	achievements(){
		savePhrase.bkgdc = new Color(224,255,224);
		unlockPhrase.bkgdc = new Color(224,224,255);
		start();
	}
	void start(){if(t == null){t = new Thread(this);t.start();}}
	public void run(){
		while(alive == true){
			if(wonderlandMain.p1.stepsTaken >= 400 && wonderlandMain.p1.skinsUnlocked[2] == 0){
				wonderlandMain.p1.skinsUnlocked[2] = 1;
				unlockPhrase.changePhrase("Blue elf skin unlocked!");
				unlockPhrase.activate("s");
			}
			if(wonderlandMain.p1.numCollisions >= 20 && wonderlandMain.p1.skinsUnlocked[3] == 0){
				wonderlandMain.p1.skinsUnlocked[3] = 1;
				unlockPhrase.changePhrase("Gray elf skin unlocked!");
				unlockPhrase.activate("s");
			}
			if(wonderlandMain.p1.numInteractions >= 150 && wonderlandMain.p1.skinsUnlocked[4] == 0){
				wonderlandMain.p1.skinsUnlocked[4] = 1;
				unlockPhrase.changePhrase("Orange elf skin unlocked!");
				unlockPhrase.activate("s");
			}
			if(wonderlandMain.p1.numInteractions > wonderlandMain.p1.stepsTaken && wonderlandMain.p1.skinsUnlocked[5] == 0){
				wonderlandMain.p1.skinsUnlocked[5] = 1;
				unlockPhrase.changePhrase("Purple elf skin unlocked!");
				unlockPhrase.activate("s");
			}
			if(((wonderlandMain.p1.leftOrRight == 0 && wonderlandMain.p1.moveRight == true) || (wonderlandMain.p1.leftOrRight == 1 && wonderlandMain.p1.moveLeft == true)) && wonderlandMain.p1.skinsUnlocked[6] == 0){
				wonderlandMain.p1.skinsUnlocked[6] = 1;
				unlockPhrase.changePhrase("Inverted elf skin unlocked!");
				unlockPhrase.activate("s");
			}
			if(wonderlandMain.p1.numPengInteractions >= 75 && wonderlandMain.p1.skinsUnlocked[8] == 0){
				wonderlandMain.p1.skinsUnlocked[8] = 1;
				unlockPhrase.changePhrase("Penguin elf skin unlocked!");
				unlockPhrase.activate("s");
			}
			if(wonderlandMain.p1.numPengInteractions >= 10 && wonderlandMain.p1.numGobInteractions >= 10 && wonderlandMain.p1.skinsUnlocked[9] == 0){
				wonderlandMain.p1.skinsUnlocked[9] = 1;
				unlockPhrase.changePhrase("Rainbow elf skin unlocked!");
				unlockPhrase.activate("s");
			}
			if(wonderlandMain.p1.minutesPlayed >= 60 && wonderlandMain.p1.skinsUnlocked[10] == 0){
				wonderlandMain.p1.skinsUnlocked[10] = 1;
				unlockPhrase.changePhrase("Old elf skin unlocked!");
				unlockPhrase.activate("s");
			}
			if(wonderlandMain.p1.numCollisions >= 100 && wonderlandMain.p1.skinsUnlocked[11] == 0){
				wonderlandMain.p1.skinsUnlocked[11] = 1;
				unlockPhrase.changePhrase("Blindfolded elf skin unlocked!");
				unlockPhrase.activate("s");
			}
			if(wonderlandMain.p1.numGobInteractions >= 75 && wonderlandMain.p1.skinsUnlocked[12] == 0){
				wonderlandMain.p1.skinsUnlocked[12] = 1;
				unlockPhrase.changePhrase("Goblin elf skin unlocked!");
				unlockPhrase.activate("s");
			}
			if(ghostPhrase == true && wonderlandMain.p1.skinsUnlocked[13] == 0){
				wonderlandMain.p1.skinsUnlocked[13] = 1;
				unlockPhrase.changePhrase("Ghost elf skin unlocked!");
				unlockPhrase.activate("s");
			}
			if(wonderlandMain.p1.numRudInteractions >= 4 && wonderlandMain.p1.skinsUnlocked[14] == 0){
				wonderlandMain.p1.skinsUnlocked[14] = 1;
				unlockPhrase.changePhrase("Rudolph skin unlocked!");
				unlockPhrase.activate("s");
			}
			try{t.sleep(tt);}catch(Exception e){}
		}
	}
	void saveData(){
		try{
			FileOutputStream fos = new FileOutputStream(data);
			fos.write(47);
			for(int i = 1;i<wonderlandMain.p1.numSkins;i++){
				if(wonderlandMain.p1.skinsUnlocked[i] == 0){
					fos.write(48);
				}else{fos.write(49);}
			}
			fos.write(92);
			intToBytes(fos,wonderlandMain.p1.numInteractions);
			intToBytes(fos,wonderlandMain.p1.numPengInteractions);
			intToBytes(fos,wonderlandMain.p1.numBearInteractions);
			intToBytes(fos,wonderlandMain.p1.numGobInteractions);
			intToBytes(fos,wonderlandMain.p1.numFairyInteractions);
			intToBytes(fos,wonderlandMain.p1.numReinInteractions);
			intToBytes(fos,wonderlandMain.p1.numRudInteractions);
			intToBytes(fos,wonderlandMain.p1.stepsTaken);
			intToBytes(fos,wonderlandMain.p1.numCollisions);
			intToBytes(fos,wonderlandMain.p1.minutesPlayed);
			fos.close();
		}catch(Exception e){}
		savePhrase.activate("s");
	}
	void loadData(){
		try{
			System.out.println("Loading data...");
			FileInputStream fis = new FileInputStream(data);
			System.out.println("Loading skin data...");
			fis.read();
			for(int i = 1;i<wonderlandMain.p1.numSkins;i++){
				if(fis.read() == 49){
					wonderlandMain.p1.skinsUnlocked[i] = 1;
				}else{
					wonderlandMain.p1.skinsUnlocked[i] = 0;
				}
			}
			fis.read();
			wonderlandMain.p1.numInteractions = bytesToInt(fis);
			wonderlandMain.p1.numPengInteractions = bytesToInt(fis);
			wonderlandMain.p1.numBearInteractions = bytesToInt(fis);
			wonderlandMain.p1.numGobInteractions = bytesToInt(fis);
			wonderlandMain.p1.numFairyInteractions = bytesToInt(fis);
			wonderlandMain.p1.numReinInteractions = bytesToInt(fis);
			wonderlandMain.p1.numRudInteractions = bytesToInt(fis);
			wonderlandMain.p1.stepsTaken = bytesToInt(fis);
			wonderlandMain.p1.numCollisions = bytesToInt(fis);
			wonderlandMain.p1.minutesPlayed = bytesToInt(fis);
			System.out.println("Data loaded Successfully.");
			fis.close();
		}catch(Exception e){}
	}
	void intToBytes(FileOutputStream fs, int inpi){
		Integer a = inpi;
		String b = a.toString();
		try{
			fs.write(48+b.length());
			fs.write(44);
			fs.write(b.getBytes());
			fs.write(92);
		}catch(Exception e){System.out.println("Uh oh.");}
	}
	int bytesToInt(FileInputStream fs){
		try{
			Integer a = fs.read()-48;
			fs.read();
			Integer[] b = new Integer[a];
			byte[] c = new byte[a];
			for(int i = 0;i<a;i++){
				b[i] = fs.read();
				c[i] = b[i].byteValue();
			}
			String d = new String(c);
			fs.read();
			return(a.parseInt(d));
		}catch(Exception e){System.out.println("Uh oh.");}
		return(0);
	}
}