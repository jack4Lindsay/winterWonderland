package wonderland;
import java.awt.event.*;
class keys extends KeyAdapter{
	public void keyPressed(KeyEvent ke){
		if(ke.getKeyCode() == 87){
			wonderlandMain.p1.moveUp = true;
		}
		if(ke.getKeyCode() == 65){
			wonderlandMain.p1.moveLeft = true;
			wonderlandMain.p1.leftOrRight = 0;
		}
		if(ke.getKeyCode() == 83){
			wonderlandMain.p1.moveDown = true;
		}
		if(ke.getKeyCode() == 68){
			wonderlandMain.p1.moveRight = true;
			wonderlandMain.p1.leftOrRight = 1;
		}
		if(ke.getKeyCode() == 39){
			if(wonderlandMain.p1.skinID == wonderlandMain.p1.numSkins-1){
				wonderlandMain.p1.skinID = 0;
			}else{wonderlandMain.p1.skinID++;}
			while(wonderlandMain.p1.skinsUnlocked[wonderlandMain.p1.skinID] == 0){
				if(wonderlandMain.p1.skinID == wonderlandMain.p1.numSkins-1){
					wonderlandMain.p1.skinID = 0;
				}else{wonderlandMain.p1.skinID++;}
			}
		}
		if(ke.getKeyCode() == 37){
			if(wonderlandMain.p1.skinID == 0){
				wonderlandMain.p1.skinID = wonderlandMain.p1.numSkins-1;
			}else{wonderlandMain.p1.skinID--;}
			while(wonderlandMain.p1.skinsUnlocked[wonderlandMain.p1.skinID] == 0){
				if(wonderlandMain.p1.skinID == 0){
					wonderlandMain.p1.skinID = wonderlandMain.p1.numSkins-1;
				}else{wonderlandMain.p1.skinID--;}
			}
		}
		if(ke.getKeyCode() == 86){wonderlandMain.ach.saveData();}
	}
	public void keyReleased(KeyEvent ke){
		if(ke.getKeyCode() == 87){
			wonderlandMain.p1.moveUp = false;
		}
		if(ke.getKeyCode() == 65){
			wonderlandMain.p1.moveLeft = false;
		}
		if(ke.getKeyCode() == 83){
			wonderlandMain.p1.moveDown = false;
		}
		if(ke.getKeyCode() == 68){
			wonderlandMain.p1.moveRight = false;
		}
	}
}