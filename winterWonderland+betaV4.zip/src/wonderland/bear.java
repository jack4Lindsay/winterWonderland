package wonderland;
import java.awt.*;
import java.io.*;
import javax.imageio.*;
import java.awt.event.*;
class bear extends neutralEntity{
	File f = new File(wonderlandMain.dir + "wonderland+polar+bear.png");
	bear(){
		super();
		try{im = ImageIO.read(f);}catch(Exception e){}
		l = 160;
		h = 160;
		numAnim = 32;
	}
	bear(int inpx, int inpy){
		super(inpx, inpy);
		try{im = ImageIO.read(f);}catch(Exception e){}
		l = 160;
		h = 160;
		numAnim = 32;
	}
	public void paintComponent(Graphics com){
		Graphics2D g = (Graphics2D) com;
		animate();
		g.drawImage(im,0,0,l,h,(skinID*32)+(anim*16)+(leftOrRight*16),(stillOrMove*16),(skinID*32)+(anim*16)+16-(leftOrRight*16),(stillOrMove*16)+16,null);
		highlightCheck(g);
	}
	public void mouseClicked(MouseEvent me){ph.activate("po");interacted = true;}
	public void mouseDragged(MouseEvent me){ph.activate("po");interacted = true;}
}