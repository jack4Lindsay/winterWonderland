package wonderland;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.*;
class snowflake extends JComponent implements Runnable{
	Thread t;
	int tt = 4;
	boolean alive = true;
	int x = 0, y = -16, size = 8;
	Random ra = new Random();
	Rectangle2D.Float snow = new Rectangle2D.Float();
	snowflake(){
		setBounds(0,0,wonderlandMain.l,wonderlandMain.h);
		x = ra.nextInt(wonderlandMain.l);
		y = ra.nextInt(wonderlandMain.h);
		start();
	}
	public void paintComponent(Graphics com){
		Graphics2D g = (Graphics2D) com;
		g.setColor(Color.WHITE);
		snow.setFrame(x,y,size,size);
		g.fill(snow);
	}
	void start(){if(t == null){t = new Thread(wonderlandMain.sftg,this);t.start();}}
	public void run(){
		while(alive == true){
			if(x < wonderlandMain.l+16){x++;}else{x = -16;}
			if(y < wonderlandMain.h+16){y++;}else{x = ra.nextInt(wonderlandMain.l);y = -16;}
			repaint();
			try{t.sleep(tt);}catch(Exception e){}
		}
	}
}