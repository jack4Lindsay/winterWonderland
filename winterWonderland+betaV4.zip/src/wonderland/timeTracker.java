package wonderland;

class timeTracker implements Runnable{
	Thread t;
	int tt = 60000;
	boolean alive = true;
	timeTracker(){
		start();
	}
	void start(){if(t == null){t = new Thread(this);t.start();}}
	public void run(){
		while(alive == true){
			try{t.sleep(tt);}catch(Exception e){}
			wonderlandMain.p1.minutesPlayed++;
		}
	}
}