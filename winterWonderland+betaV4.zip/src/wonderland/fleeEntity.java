package wonderland;
import java.awt.*;
import java.awt.image.*;
class fleeEntity extends relativeObject{
	BufferedImage im;
	int skinID = 0;
	int counter = 0, anim = 0, numCounterCycles = 128;
	int spotted = 0, leftOrRight = 0;
	int xspd = 0, yspd = 0, speed = 1;
	fleeEntity(){
		super();
	}
	fleeEntity(int inpx, int inpy){
		super(inpx, inpy);
	}
	public void paintComponent(Graphics com){
		Graphics2D g = (Graphics2D) com;
		if(interacted == false){
			animate();
		}
		g.drawImage(im,0,0,l,h,(skinID*32)+(anim*16)+(leftOrRight*16),(spotted*16),(skinID*32)+(anim*16)+16-(leftOrRight*16),(spotted*16)+16,null);
		highlightCheck(g);
	}
	void animate(){
		if(wonderlandMain.p1.x-(x-wonderlandMain.p1.relx) < 256 && (x-wonderlandMain.p1.relx)-wonderlandMain.p1.x < 256 && wonderlandMain.p1.y-(y-wonderlandMain.p1.rely) < 256 && (y-wonderlandMain.p1.rely)-wonderlandMain.p1.y < 256 && interacted == true){
			spotted = 1;
		}
		if(spotted == 0){
			if(counter >= numCounterCycles){
				counter = 0;
				if(anim == 1){anim = 0;}else{anim++;}
			}
			counter++;
		}else{
			if(wonderlandMain.p1.x < (x-wonderlandMain.p1.relx)){
				xspd = speed;
				leftOrRight = 1;
			}else if((x-wonderlandMain.p1.relx) < wonderlandMain.p1.x){
				xspd = -speed;
				leftOrRight = 0;
			}
			if(wonderlandMain.p1.y < (y-wonderlandMain.p1.rely)){
				yspd = speed;
			}else if((y-wonderlandMain.p1.rely) < wonderlandMain.p1.y){
				yspd = -speed;
			}
			if(counter % 2 == 0){
				x+=xspd;
				y+=yspd;
			}
			if(counter >= numCounterCycles/2){
				counter = 0;
				if(anim == 1){anim = 0;}else{anim++;}
			}
			counter++;
		}
	}
}