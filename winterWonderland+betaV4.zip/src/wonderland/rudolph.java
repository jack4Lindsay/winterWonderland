package wonderland;
import java.io.*;
import javax.imageio.*;
import java.awt.event.*;
class rudolph extends fleeEntity{
	File f = new File(wonderlandMain.dir + "wonderland+rudolph.png");
	rudolph(){
		super();
		try{im = ImageIO.read(f);}catch(Exception e){}
		numCounterCycles = 192;
		speed = 2;
		System.out.println("x: " + x + " y: " + y);
		wonderlandMain.specialPhrase.activate("s");
	}
	rudolph(int inpx, int inpy){
		super(inpx, inpy);
		try{im = ImageIO.read(f);}catch(Exception e){}
		skinID = ra.nextInt(4);
		numCounterCycles = 192;
		speed = 2;
		System.out.println("x: " + x + " y: " + y);
		wonderlandMain.specialPhrase.activate("s");
	}
	public void mouseClicked(MouseEvent me){ph.activate("ru");interacted = true;}
	public void mouseDragged(MouseEvent me){ph.activate("ru");interacted = true;}
}