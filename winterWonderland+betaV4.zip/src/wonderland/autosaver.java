package wonderland;

class autosaver implements Runnable{
	Thread t;
	int tt = 900000;
	boolean alive = true;
	autosaver(){
		start();
	}
	void start(){if(t == null){t = new Thread(this);t.start();}}
	public void run(){
		while(alive == true){
			try{t.sleep(tt);}catch(Exception e){}
			wonderlandMain.ach.saveData();
		}
	}
}