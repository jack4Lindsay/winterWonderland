package wonderland;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.*;
class snowman extends relativeObject{
	BufferedImage im;
	File f = new File(wonderlandMain.dir + "wonderland+snowman.png");
	int snowID = 0;
	snowman(){
		super();
		snowID = ra.nextInt(4);
		try{im = ImageIO.read(f);}catch(Exception e){}
	}
	snowman(int inpx, int inpy){
		super(inpx, inpy);
		snowID = ra.nextInt(4);
		try{im = ImageIO.read(f);}catch(Exception e){}
	}
	public void paintComponent(Graphics com){
		Graphics2D g = (Graphics2D) com;
		g.drawImage(im,0,0,l,h,16*snowID,0,16+(16*snowID),16,null);
		highlightCheck(g);
	}
}