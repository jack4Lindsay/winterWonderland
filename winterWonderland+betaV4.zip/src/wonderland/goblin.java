package wonderland;
import java.io.*;
import javax.imageio.*;
import java.awt.event.*;
class goblin extends chaseEntity{
	File f = new File(wonderlandMain.dir + "wonderland+goblin.png");
	goblin(){
		super();
		try{im = ImageIO.read(f);}catch(Exception e){}
		skinID = ra.nextInt(4);
		l = 112;
		h = 112;
	}
	goblin(int inpx, int inpy){
		super(inpx, inpy);
		try{im = ImageIO.read(f);}catch(Exception e){}
		skinID = ra.nextInt(4);
		l = 112;
		h = 112;
	}
	public void mouseClicked(MouseEvent me){ph.activate("go");interacted = true;}
	public void mouseDragged(MouseEvent me){ph.activate("go");interacted = true;}
}