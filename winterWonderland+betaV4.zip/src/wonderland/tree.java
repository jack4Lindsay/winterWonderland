package wonderland;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.*;
class tree extends relativeObject{
	BufferedImage im;
	File f = new File(wonderlandMain.dir + "wonderland+tree.png");
	int treeID = 0;
	tree(){
		super();
		treeID = ra.nextInt(4);
		if(treeID == 0 || treeID == 3){l = 192;}else{l = 144;}
		h = 192;
		try{im = ImageIO.read(f);}catch(Exception e){}
	}
	tree(int inpx, int inpy){
		super(inpx, inpy);
		treeID = ra.nextInt(4);
		if(treeID == 0 || treeID == 3){l = 192;}else{l = 144;}
		h = 192;
		try{im = ImageIO.read(f);}catch(Exception e){}
	}
	public void paintComponent(Graphics com){
		Graphics2D g = (Graphics2D) com;
		if(treeID == 0 || treeID == 3){
			g.drawImage(im,0,0,l,h,treeID*16,0,(treeID*16)+16,16,null);
		}else{g.drawImage(im,-24,0,l+24,h,treeID*16,0,(treeID*16)+16,16,null);}
		highlightCheck(g);
	}
}