package wonderland;
import java.io.*;
import javax.imageio.*;
import java.awt.event.*;
class penguin extends neutralEntity{
	File f = new File(wonderlandMain.dir + "wonderland+penguin.png");
	penguin(){
		super();
		try{im = ImageIO.read(f);}catch(Exception e){}
		skinID = ra.nextInt(5);
		l = 64;
		h = 64;
	}
	penguin(int inpx, int inpy){
		super(inpx, inpy);
		try{im = ImageIO.read(f);}catch(Exception e){}
		skinID = ra.nextInt(5);
		l = 64;
		h = 64;
	}
	public void mouseClicked(MouseEvent me){ph.activate("pe");interacted = true;}
	public void mouseDragged(MouseEvent me){ph.activate("pe");interacted = true;}
}