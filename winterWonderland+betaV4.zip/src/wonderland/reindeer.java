package wonderland;
import java.io.*;
import javax.imageio.*;
import java.awt.event.*;
class reindeer extends fleeEntity{
	File f = new File(wonderlandMain.dir + "wonderland+reindeer.png");
	reindeer(){
		super();
		try{im = ImageIO.read(f);}catch(Exception e){}
		numCounterCycles = 192;
		speed = 2;
	}
	reindeer(int inpx, int inpy){
		super(inpx, inpy);
		try{im = ImageIO.read(f);}catch(Exception e){}
		skinID = ra.nextInt(4);
		numCounterCycles = 192;
		speed = 2;
	}
	public void mouseClicked(MouseEvent me){ph.activate("re");interacted = true;}
	public void mouseDragged(MouseEvent me){ph.activate("re");interacted = true;}
}